<?php   

$conn= mysql_connect("localhost","root","","News") or die("connection failed");




?>